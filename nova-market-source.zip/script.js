const products = [
  {
    id: 'pulse-headphones', name: 'Pulse wireless headphones', category: 'Audio & tech', group: 'audio', price: 68, oldPrice: 89, tag: 'Best seller', rating: '4.9', image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=900&q=85',
    gallery: ['https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=1200&q=85', 'https://images.unsplash.com/photo-1546435770-a3e426bf472b?auto=format&fit=crop&w=1200&q=85', 'https://images.unsplash.com/photo-1484704849700-f032a568e944?auto=format&fit=crop&w=1200&q=85'],
    description: 'Your favorite songs, podcasts, and quiet moments, all sounding a little better. Made for all-day comfort and easy listening.', detail: 'Soft-touch ear cups, clear everyday sound, and a comfortable over-ear fit. Includes a compact carrying pouch and a USB-C charging cable.'
  },
  {
    id: 'everyday-runner', name: 'Everyday runner sneaker', category: 'Style', group: 'style', price: 74, oldPrice: 92, tag: 'A nova pick', rating: '4.8', image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=900&q=85',
    gallery: ['https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=1200&q=85', 'https://images.unsplash.com/photo-1552346154-21d32810aba3?auto=format&fit=crop&w=1200&q=85', 'https://images.unsplash.com/photo-1495555961986-6d4c1ecb7be3?auto=format&fit=crop&w=1200&q=85'],
    description: 'A pop of color, a cloud-soft step, and a shape that goes with just about everything. Your new everyday favorite starts here.', detail: 'Lightweight cushioning, breathable lining, and a flexible rubber sole. Designed for long walks, everyday errands, and anywhere in between.'
  },
  {
    id: 'soft-throw', name: 'Sunday soft-knit throw', category: 'Home living', group: 'home', price: 58, oldPrice: 72, tag: 'Small-batch', rating: '5.0', image: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=900&q=85',
    gallery: ['https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1200&q=85', 'https://images.unsplash.com/photo-1600210491892-03d54c0aaf87?auto=format&fit=crop&w=1200&q=85', 'https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&w=1200&q=85'],
    description: 'The softest invitation to stay in. A relaxed, textured throw for the sofa, the reading chair, or one more cup of tea.', detail: 'Woven from a soft recycled cotton blend with a gentle, breathable feel. Finished with a subtle fringe. Machine wash cold and lay flat to dry.'
  },
  {
    id: 'daylight-watch', name: 'Daylight everyday watch', category: 'Audio & tech', group: 'audio', price: 86, oldPrice: 105, tag: 'Just in', rating: '4.7', image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=900&q=85',
    gallery: ['https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=1200&q=85', 'https://images.unsplash.com/photo-1524805444758-089113d48a6d?auto=format&fit=crop&w=1200&q=85', 'https://images.unsplash.com/photo-1434056886845-dac89ffe9b56?auto=format&fit=crop&w=1200&q=85'],
    description: 'A clean little classic that keeps time and keeps its cool. Made to wear with your favorite things, every single day.', detail: 'Minimal quartz movement with a stainless-steel case, soft leather strap, and water resistance for daily wear. Comes in a reusable keepsake box.'
  },
  {
    id: 'weekend-tote', name: 'The weekend carry-all', category: 'Style', group: 'style', price: 49, oldPrice: 64, tag: 'Easy favorite', rating: '4.9', image: 'https://images.unsplash.com/photo-1590874103328-eac38a683ce7?auto=format&fit=crop&w=900&q=85',
    gallery: ['https://images.unsplash.com/photo-1590874103328-eac38a683ce7?auto=format&fit=crop&w=1200&q=85', 'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=1200&q=85', 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=1200&q=85'],
    description: 'Room for the book, the market flowers, and that thing you nearly forgot. A simple carry-all with an easy, everyday feel.', detail: 'Made from sturdy cotton canvas with a roomy interior pocket and reinforced straps. Holds your daily essentials without weighing you down.'
  },
  {
    id: 'mini-speaker', name: 'Little room Bluetooth speaker', category: 'Audio & tech', group: 'audio', price: 54, oldPrice: 69, tag: 'Good sound', rating: '4.8', image: 'https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?auto=format&fit=crop&w=900&q=85',
    gallery: ['https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?auto=format&fit=crop&w=1200&q=85', 'https://images.unsplash.com/photo-1589003077984-894e133dabab?auto=format&fit=crop&w=1200&q=85', 'https://images.unsplash.com/photo-1589256469067-ea99122bbdc4?auto=format&fit=crop&w=1200&q=85'],
    description: 'Big-hearted sound in a small, easy-to-place package. Bring a little soundtrack to your kitchen, desk, or next picnic.', detail: 'Pair with your phone in seconds. Enjoy up to 10 hours of playtime, simple tactile controls, and a compact size that travels well.'
  },
  {
    id: 'soft-glow-lamp', name: 'Soft glow bedside lamp', category: 'Home living', group: 'home', price: 62, oldPrice: 78, tag: 'Warm light', rating: '4.8', image: 'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=900&q=85',
    gallery: ['https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=1200&q=85', 'https://images.unsplash.com/photo-1507473885765-33ed22f7f4a4?auto=format&fit=crop&w=1200&q=85', 'https://images.unsplash.com/photo-1513506003901-1e6a229e2d15?auto=format&fit=crop&w=1200&q=85'],
    description: 'A gentle pool of light for the slower parts of your day. An easy, sculptural shape made to sit happily on a side table.', detail: 'Warm LED light with three brightness settings and a soft-touch switch. Includes the lamp, LED bulb, and a 1.5 metre cord.'
  },
  {
    id: 'active-runner', name: 'Move-light active sneaker', category: 'Active life', group: 'active', price: 79, oldPrice: 98, tag: 'On the move', rating: '4.9', image: 'https://images.unsplash.com/photo-1552346154-21d32810aba3?auto=format&fit=crop&w=900&q=85',
    gallery: ['https://images.unsplash.com/photo-1552346154-21d32810aba3?auto=format&fit=crop&w=1200&q=85', 'https://images.unsplash.com/photo-1495555961986-6d4c1ecb7be3?auto=format&fit=crop&w=1200&q=85', 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=1200&q=85'],
    description: 'A light, supportive everyday shoe that keeps up with your plans. From an early walk to the long way home.', detail: 'Breathable knit upper, cushioned footbed, and a grippy flexible sole. Made for light training and everyday movement.'
  }
];

const formatPrice = (amount) => `$${amount.toFixed(2)}`;

function readCart() {
  try { return JSON.parse(localStorage.getItem('nova-market-cart') || '{}'); }
  catch { return {}; }
}

function updateCartCount() {
  const cart = readCart();
  const count = Object.values(cart).reduce((total, quantity) => total + Number(quantity || 0), 0);
  document.querySelectorAll('[data-cart-count]').forEach((badge) => { badge.textContent = count; });
}

function addToCart(productId, quantity = 1) {
  const cart = readCart();
  cart[productId] = (Number(cart[productId]) || 0) + Number(quantity);
  localStorage.setItem('nova-market-cart', JSON.stringify(cart));
  updateCartCount();
  const product = products.find((item) => item.id === productId);
  const toastMessage = document.getElementById('cartToastMessage');
  if (toastMessage && product) toastMessage.textContent = `${product.name} added to your bag`;
  const toastElement = document.getElementById('cartToast');
  if (toastElement && window.bootstrap) bootstrap.Toast.getOrCreateInstance(toastElement).show();
}

function createProductCard(product) {
  const oldPrice = product.oldPrice ? `<span class="old-price">${formatPrice(product.oldPrice)}</span><span class="product-save">Save ${Math.round((1 - product.price / product.oldPrice) * 100)}%</span>` : '';
  const tag = product.tag ? `<span class="product-tag">${product.tag}</span>` : '';
  return `<div class="col-6 col-md-4 col-xl-3"><article class="product-card">
    <div class="product-art"><a href="product.html?id=${encodeURIComponent(product.id)}" aria-label="View ${product.name}"><img src="${product.image}" alt="${product.name}" loading="lazy"></a>${tag}<button class="product-favorite" type="button" aria-label="Add ${product.name} to favorites" aria-pressed="false"><i class="bi bi-heart"></i></button></div>
    <div class="product-card-body"><span class="product-card-category">${product.category}</span><a class="product-card-title" href="product.html?id=${encodeURIComponent(product.id)}">${product.name}</a><div class="product-card-rating"><span class="stars">★★★★★</span><span>${product.rating}</span></div><div class="product-price-line"><span>${formatPrice(product.price)}</span>${oldPrice}</div><button class="product-quick-add" type="button" data-add-cart="${product.id}"><i class="bi bi-plus me-1"></i> Add to bag</button></div>
  </article></div>`;
}

function renderProducts(target, list) {
  const container = document.getElementById(target);
  if (!container) return;
  container.innerHTML = list.length ? list.map(createProductCard).join('') : '<div class="product-empty">Nothing here just yet. Try another category or search.</div>';
}

function initHome() {
  const saleProducts = products.filter((product) => product.oldPrice).slice(0, 4);
  const latestProducts = [products[4], products[5], products[6], products[7]];
  let currentFilter = 'all';
  let query = new URLSearchParams(window.location.search).get('search') || '';
  const searchBox = document.querySelector('.header-search input');
  if (searchBox) searchBox.value = query;

  const filterProducts = () => {
    const matches = (product) => (currentFilter === 'all' || product.group === currentFilter) && (!query || `${product.name} ${product.category} ${product.description}`.toLowerCase().includes(query.toLowerCase()));
    renderProducts('saleProducts', saleProducts.filter(matches));
    renderProducts('latestProducts', latestProducts.filter(matches));
  };
  const selectFilter = (filter) => {
    currentFilter = filter;
    document.querySelectorAll('[data-filter]').forEach((button) => button.classList.toggle('active', button.dataset.filter === filter));
    filterProducts();
    const panel = document.getElementById('categoryPanel');
    if (panel && window.innerWidth < 992) panel.classList.remove('is-open');
  };

  filterProducts();
  document.querySelectorAll('[data-filter]').forEach((button) => button.addEventListener('click', () => selectFilter(button.dataset.filter)));
  document.querySelectorAll('[data-reset-filter]').forEach((link) => link.addEventListener('click', (event) => { event.preventDefault(); query = ''; if (searchBox) searchBox.value = ''; selectFilter('all'); document.getElementById('products')?.scrollIntoView({ behavior: 'smooth' }); }));
  document.querySelectorAll('[data-hero-filter]').forEach((link) => link.addEventListener('click', () => selectFilter(link.dataset.heroFilter)));
  const mobileToggle = document.querySelector('.category-mobile-toggle');
  mobileToggle?.addEventListener('click', () => {
    const panel = document.getElementById('categoryPanel');
    const open = panel.classList.toggle('is-open');
    mobileToggle.setAttribute('aria-expanded', String(open));
  });
  document.querySelector('.header-search')?.addEventListener('submit', (event) => {
    event.preventDefault();
    query = searchBox.value.trim();
    filterProducts();
    document.getElementById('products')?.scrollIntoView({ behavior: 'smooth' });
  });
  document.querySelectorAll('[data-add-cart]').forEach((button) => button.addEventListener('click', () => addToCart(button.dataset.addCart)));
  document.querySelectorAll('.product-favorite').forEach((button) => button.addEventListener('click', () => {
    const active = button.getAttribute('aria-pressed') !== 'true';
    button.setAttribute('aria-pressed', String(active));
    button.innerHTML = active ? '<i class="bi bi-heart-fill"></i>' : '<i class="bi bi-heart"></i>';
  }));
  document.getElementById('newsletterForm')?.addEventListener('submit', (event) => {
    event.preventDefault();
    const message = document.getElementById('newsletterMessage');
    if (message) message.textContent = 'You’re on the list. Thanks for being here!';
    event.currentTarget.reset();
  });
}

function initProduct() {
  const params = new URLSearchParams(window.location.search);
  const product = products.find((item) => item.id === params.get('id')) || products[1];
  const setText = (id, value) => { const element = document.getElementById(id); if (element) element.textContent = value; };
  document.title = `${product.name} — Nova Market`;
  setText('breadcrumbProduct', product.name);
  setText('detailCategory', product.category);
  setText('detailTitle', product.name);
  setText('detailPrice', formatPrice(product.price));
  setText('addDetailPrice', formatPrice(product.price));
  setText('detailDescription', product.description);
  setText('detailLongDescription', product.detail);
  setText('detailBadge', product.tag || 'NOVA PICK');
  if (product.oldPrice) {
    setText('detailOldPrice', formatPrice(product.oldPrice));
    setText('detailSave', `Save ${Math.round((1 - product.price / product.oldPrice) * 100)}%`);
  }

  const mainImage = document.getElementById('mainProductImage');
  const thumbs = document.getElementById('productThumbnails');
  if (mainImage) { mainImage.src = product.gallery[0]; mainImage.alt = product.name; }
  if (thumbs) {
    thumbs.innerHTML = product.gallery.map((image, index) => `<button type="button" class="product-thumb${index === 0 ? ' active' : ''}" data-image-index="${index}" aria-label="View product image ${index + 1}" aria-pressed="${index === 0}"><img src="${image}" alt="" loading="lazy"></button>`).join('');
    thumbs.querySelectorAll('[data-image-index]').forEach((button) => button.addEventListener('click', () => {
      const image = product.gallery[Number(button.dataset.imageIndex)];
      mainImage.src = image;
      thumbs.querySelectorAll('.product-thumb').forEach((thumb) => { const active = thumb === button; thumb.classList.toggle('active', active); thumb.setAttribute('aria-pressed', String(active)); });
    }));
  }
  const similar = products.filter((item) => item.id !== product.id && (item.group === product.group || item.group === 'style')).slice(0, 4);
  renderProducts('similarProducts', similar);
  document.querySelectorAll('[data-add-cart]').forEach((button) => button.addEventListener('click', () => addToCart(button.dataset.addCart)));
  document.querySelectorAll('.product-favorite').forEach((button) => button.addEventListener('click', () => {
    const active = button.getAttribute('aria-pressed') !== 'true';
    button.setAttribute('aria-pressed', String(active));
    button.innerHTML = active ? '<i class="bi bi-heart-fill"></i>' : '<i class="bi bi-heart"></i>';
  }));

  let quantity = 1;
  const quantityOutput = document.getElementById('quantityValue');
  const updateQuantity = () => {
    if (quantityOutput) quantityOutput.value = String(quantity);
    setText('addDetailPrice', formatPrice(product.price * quantity));
  };
  document.getElementById('quantityMinus')?.addEventListener('click', () => { quantity = Math.max(1, quantity - 1); updateQuantity(); });
  document.getElementById('quantityPlus')?.addEventListener('click', () => { quantity = Math.min(99, quantity + 1); updateQuantity(); });
  document.getElementById('addDetailToCart')?.addEventListener('click', () => addToCart(product.id, quantity));

  const colorNames = ['Warm red', 'Soft cream', 'Olive green'];
  document.querySelectorAll('.color-swatch').forEach((button, index) => button.addEventListener('click', () => {
    document.querySelectorAll('.color-swatch').forEach((swatch) => { const active = swatch === button; swatch.classList.toggle('selected', active); swatch.setAttribute('aria-pressed', String(active)); });
    setText('selectedColor', colorNames[index]);
  }));
}

document.querySelectorAll('img').forEach((image) => image.addEventListener('error', () => {
  image.style.visibility = 'hidden';
  image.closest('.product-art, .product-main-image, .product-thumb, .category-card, .hero-visual, .feature-banner-image')?.classList.add('image-unavailable');
}, { once: true }));
updateCartCount();
if (document.body.dataset.page === 'product') initProduct();
else initHome();
