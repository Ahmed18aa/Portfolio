# Nova Market — Ecommerce playlist project

A responsive front-end ecommerce demo inspired by the topics in GreatStack's six-part playlist. It includes a Bootstrap navigation bar, mobile category menu, rotating hero banners, category filters, sale and new-product cards, store features, footer, and a product detail page with an image gallery and similar products.

## Run the website

1. Extract the project ZIP, then open the extracted project folder.
2. Open a terminal in the extracted `ecommerce-playlist-complete` folder.
3. Start a small local web server:

   ```bash
   py -m http.server 8000
   ```

   If `py` is unavailable, try `python -m http.server 8000`.

4. Open [http://localhost:8000](http://localhost:8000) in your browser.
5. Select a product to open its detail page. The bag count is saved in that browser with local storage.

An internet connection is needed for the Bootstrap files, fonts, and demo product photos loaded from their CDNs.

## Files

- `index.html` — home page, categories, carousel, sale and latest products, benefits, newsletter form, and footer.
- `product.html` — product information, gallery, color selector, quantity control, add-to-bag action, and similar products.
- `style.css` — responsive layout, colors, typography, hover states, and mobile breakpoints.
- `script.js` — product cards, category/search filtering, gallery, quantity controls, and demo bag state.

## Demo limits

This is a static front-end project. The bag is stored only in the current browser; there is no real checkout, payment, inventory, or email subscription service. Replace the sample products, prices, photos, and store contact details before using it as a real shop.

## About the original tutorial source

This folder is a newly written implementation of the playlist topics, not a copy of GreatStack's original project files. GreatStack's course page says the project code is available inside the course: [Make Ecommerce Website Front-End Using HTML CSS Bootstrap](https://www.udemy.com/course/make-ecommerce-website-using-html-css-bootstrap/).
